# Licenses

## Common Javascript

MIT or Apache 2.0

## Android version

MIT or Apache 2.0

## iOS/macOS version

MIT only

based on Phonegap-SQLitePlugin by @davibe (Davide Bertola <dade@dadeb.it>) and @joenoon (Joe Noon <joenoon@gmail.com>)

## Windows version

MIT or Apache 2.0

### SQLite3-WinRT [used by  Windows (8.1) version]

by @doo (doo GmbH)

MIT License

## WP(7/8) version

MIT or Apache 2.0

## Class lib(s) used by WP(7/8) version

### C#-SQLite

MIT License

## SQLite3

Public domain
